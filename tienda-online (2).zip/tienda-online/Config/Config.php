<?php
const BASE_URL = "http://localhost/tienda-online/";
const HOST = "localhost";
const USER = "root";
const PASS = "";
const DB = "tienda-online";
const CHARSET = "charset=utf8";
const TITLE = "TIENDA ONLINE";
const MONEDA = "USD";
const CLIENT_ID = "Af0sZqhptlVQWJYwPhVzftAH4j34DTqTbjyf7DmVAJT0jBEbHlw7EC2doavg-F5I0JYVmw52dUYsYGCz";

const USER_SMTP = "juancamilohdzg@gmail.com";
const PASS_SMTP = "abppqascuxvfpbwn";
const PUERTO_SMTP = 465;
const HOST_SMTP = "smtp.gmail.com";
?>
